# fb-auto-reply-bot

A Facebook auto reply bot using Flask and Python.